$(document).ready(function(){
    console.log("hey i am also working");
});
