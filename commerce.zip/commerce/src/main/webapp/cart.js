$(document).ready(

    function () {
        function getCookie(name) {
        	const cookieValue = document.cookie
            .split('; ')
            .find(row => row.startsWith(name + '='));
        const value = cookieValue ? cookieValue.split('=')[1] : null;
        return value ? decodeURIComponent(value) : null;
        }

        function presentProducts(prods) {
            let proplace = $("#products_place");
            proplace.text("");
            for (let i = 0; i < prods.length; i++) {
                let obj = prods[i];

                let tempobj = $("<div></div>");
                tempobj.attr("id", "product");
                tempobj.attr("class", "col_flex");

                let imgdiv = $("<div></div>");
                imgdiv.attr("class", "imageProduct");
                let imgobj = $("<img>")
                imgobj.attr("src", "image.jpg");
                imgobj.attr("class", "orgImage");
                imgdiv.append(imgobj);
                tempobj.append(imgdiv);

                let desc = $("<p></p>").text(obj["name"]);
                tempobj.append(desc);

                let pricediv = $("<div></div>");
                pricediv.attr("class", "row_flex_1");
                let price_val = $("<p></p>").text(obj["price"]);

                let decreaseButton = $("<button></button>").attr("class", "decreaseQuantity");
                decreaseButton.attr("value", obj["proid"]);
                decreaseButton.attr("id", "decreaseQuantity");
                decreaseButton.text("-");

                let increaseButton = $("<button></button>").attr("class", "increaseQuanity");
                increaseButton.attr("value", obj["proid"]);
                increaseButton.attr("id", "increaseQuanity");
                increaseButton.text("+");

                price_val.attr("class", "orgPrice");
                pricediv.append(decreaseButton);
                pricediv.append(price_val);
                pricediv.append(increaseButton);
                tempobj.append(pricediv);

                let quandiv = $("<div></div>");
                let quan_val = $("<p></p>").text("Quantity: " + obj["quantity"]);
                if (obj["quantity"] === 1) {
                    decreaseButton.prop("disabled", true);
                }
                quan_val.attr("id", "productQuantity")
                quandiv.append(quan_val);
                tempobj.append(quandiv);

                proplace.append(tempobj);
            }

            $(".increaseQuanity").click(function () {
                let userProducts = JSON.parse(localStorage.getItem("cart_objs"));
                let currQuanity = userProducts[this.value] + 1;

                userProducts[this.value] = currQuanity;

                $(this).closest("#product").find("#productQuantity").text("Quantity: " + currQuanity);
                $(this).closest("#product").find(".decreaseQuantity").prop("disabled", false);

                localStorage.setItem("cart_objs", JSON.stringify(userProducts));
            })

            $(".decreaseQuantity").click(function () {
                let userProducts = JSON.parse(localStorage.getItem("cart_objs"));
                let currQuanity = userProducts[this.value] - 1;
                userProducts[this.value] = currQuanity;
                $(this).closest("#product").find("#productQuantity").text("Quantity: " + currQuanity);
                localStorage.setItem("cart_objs", JSON.stringify(userProducts));

                if (userProducts[this.value] == 1) {
                    $(this).prop("disabled", true);
                    return;
                }
            })
        }

        $('#takeMeToCart').click(function () {
            var userCart = localStorage.getItem("cart_objs");

            $.ajax({
                url: "http://localhost:8080/commerce/checkOut",
                method: 'GET',
                data: {
                    "userCart": userCart
                },
                success: function (response) {
                    var newWindow = window.open();
                    newWindow.document.write(response);
                },
                error: function (xhr, status, error) {
                    console.error('Error sending data:', error);
                }
            });
        });
        
        let userProducts = JSON.parse(getCookie("userProducts"))["userProducts"];
        console.log(userProducts);
        presentProducts(userProducts);
    }
)