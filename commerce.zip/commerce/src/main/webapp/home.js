$(document).ready(function(){
    var selected_items={};
    localStorage.setItem("cart_objs",JSON.stringify(selected_items));
  
    function presentProducts(prods){
        let proplace=$("#products_place");
        proplace.text("");
        for(let i=0;i<prods.length;i++){
            let obj=prods[i];

            let tempobj=$("<div></div>");
            tempobj.attr("class","col_flex");

            let imgdiv=$("<div></div>");
            imgdiv.attr("class","imageProduct");
            let imgobj=$("<img>")
            imgobj.attr("src","image.jpg");
            imgobj.attr("class","orgImage");
            imgdiv.append(imgobj);
            tempobj.append(imgdiv);

            let desc=$("<p></p>").text(obj["name"]);
            tempobj.append(desc);

            let pricediv=$("<div></div>");
            let price_val=$("<p></p>").text(obj["price"]);
            price_val.attr("class","orgPrice");
            pricediv.append(price_val);
            tempobj.append(pricediv);

            let btn=$("<button></button>").attr("class","addToCart");
            btn.attr("value",obj["proid"]);
            btn.attr("id","addToCartButton");
            // btn.attr("onclick","addItemToCart("+obj["proid"]+")");
            btn.text("Add to Cart");
            tempobj.append(btn);

            proplace.append(tempobj);
        }

        $(".addToCart").click(function(){
            let obj=JSON.parse(localStorage.getItem("cart_objs"));
            if(obj[this.value]!==undefined){
                obj[this.value]=obj[this.value]+1;
            }else{
                obj[this.value]=1;
            }
            console.log(obj[this.value]);
            localStorage.setItem("cart_objs",JSON.stringify(obj));
            console.log(JSON.parse(localStorage.getItem("cart_objs")));
        })  
    }

    $.ajax({
        url: "http://localhost:8080/commerce/products",
        method: "GET",
        success: function(result){
            let prods=result["products"];
            presentProducts(prods);
        }
    });

    $.ajax({
        url: "http://localhost:8080/commerce/categories",
        method: "GET",
        success: function(result){
            let cats=result["categories"];
            let cat_space=$("#category_space");

            for(let i=0;i<cats.length;i++){
                let cat=cats[i];
                let opt=$("<option></option>").text(cat["catname"]);
                opt.attr("value",cat["catid"]);
                cat_space.append(opt);
            }
        }
    })

    $("#takeMeToCart").on("click",function(){
        let jsonString = localStorage.getItem("cart_objs");
        let cookieString = "cart_objs" + "=" +  encodeURIComponent(jsonString);
        document.cookie = cookieString;
        window.location.href="http://localhost:8080/commerce/cart";
    })
});
