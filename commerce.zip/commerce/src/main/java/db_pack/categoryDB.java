package db_pack;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import model_pack.Category;

public class categoryDB {

	public Connection conn = null;

	public categoryDB() {
		conn = connClass.getConnection();
	}

	public ArrayList<Category> getAllCategories() {

		ArrayList<Category> cats = new ArrayList<>();

		try {
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

			ResultSet rst = st.executeQuery("select * from allCategories()");

			// private int catid;
			// private String catname;

			while (rst.next()) {
				Category temp = new Category(rst.getInt(1), rst.getString(2));
				cats.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return cats;
	}
}
