package db_pack;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

import model_pack.Order;
import model_pack.orderProduct;

public class orderDB {

	public Connection conn = null;

	public orderDB() {
		conn = connClass.getConnection();
	}

	public Order createOrder(double totalPrice) {

		Order ord = null;

		try {
			PreparedStatement st = conn.prepareStatement("SELECT * FROM createOrder(?, ?, ?);",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			System.out.println(java.sql.Date.valueOf(LocalDate.now()));
			st.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			st.setBigDecimal(2, BigDecimal.valueOf(totalPrice));
			st.setInt(3, 1);
			ResultSet rst = st.executeQuery();

			rst.next();
			ord = new Order(rst.getInt(1), rst.getDate(2), rst.getDouble(3), rst.getInt(4));

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ord;
	}

	public void createOrderProducts(ArrayList<orderProduct> userProds, Order ord) {
		try {
			PreparedStatement st = conn.prepareStatement("SELECT * FROM createOrderProduct(?, ?, ?, ?);",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			for(orderProduct ordprod : userProds) {
				st.setInt(1, ord.getOrderid());
				st.setInt(2, ordprod.getProid());
				st.setInt(3, ordprod.getQuantity());
				st.setBigDecimal(4,BigDecimal.valueOf(((ordprod.getGst()/100.0)+ordprod.getUnitprice())*ordprod.getQuantity()));
				st.executeQuery();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
