package db_pack;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class connClass {
	private static Connection cn;

	public static Connection getConnection() {
		//usage of singleton pattern
		if(cn==null) {
			try {
				Class.forName("org.postgresql.Driver");
				Properties p = new Properties();
				FileReader f = new FileReader("E:\\WorkSpaceEcclipse\\commerce\\prop.properties");
				p.load(f);
				cn = DriverManager.getConnection(p.getProperty("jdbc_conn_string"), p.getProperty("user"),
						p.getProperty("password"));
				System.out.println("Established Connection to database");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cn;
	}
}
