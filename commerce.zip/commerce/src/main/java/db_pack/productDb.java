package db_pack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import model_pack.Product;
import model_pack.productGST;

public class productDb {
	public Connection conn = null;

	public productDb() {
		conn = connClass.getConnection();
	}

	public ArrayList<Product> getAllProducts() {
		ArrayList<Product> pls = new ArrayList<>();

		// returns table(
		// proid int,
		// name varchar(100),
		// price bigint,
		// hsncode varchar(10),
		// imgpath varchar(1000),
		// catid int
		// )

		try {
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rst = st.executeQuery("select * from allProducts()");

			while (rst.next()) {
				Product temp = new Product(rst.getInt(1), rst.getString(2), rst.getLong(3), rst.getString(4),
						rst.getString(5), rst.getInt(6));
				pls.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pls;
	}

	public ArrayList<Product> getAllCategoryProducts(int catid) {
		if(catid==-1) {
			return this.getAllProducts();
		}
		ArrayList<Product> pls = new ArrayList<>();

		try {
			PreparedStatement st = conn.prepareStatement("select * from allCategoryProducts(?)",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			st.setInt(1, catid);
			ResultSet rst = st.executeQuery();

			while (rst.next()) {
				Product temp = new Product(rst.getInt(1), rst.getString(2), rst.getLong(3), rst.getString(4),
						rst.getString(5), rst.getInt(6));
				pls.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pls;
	}

	public HashMap<Product, Integer> getReqProducts(ArrayList<Integer> proids, HashMap<Integer, Integer> proQuantity) {

		HashMap<Product, Integer> pls = new HashMap<>();

		try {
			PreparedStatement st = conn.prepareStatement("select * from allRequiredProducts(?)",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			st.setArray(1, conn.createArrayOf("INTEGER", proids.toArray(new Integer[0])));
			ResultSet rst = st.executeQuery();

			while (rst.next()) {
				Product temp = new Product(rst.getInt(1), rst.getString(2), rst.getLong(3), rst.getString(4),
						rst.getString(5), rst.getInt(6));
				pls.put(temp, proQuantity.get(rst.getInt(1)));
			}
			System.out.println(pls);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pls;
	}

	public ArrayList<productGST> getProductsPriceAndGST(ArrayList<Integer> proids) {
		ArrayList<productGST> pgsts = new ArrayList<>();

		try {
			PreparedStatement st = conn.prepareStatement("select * from getProductsPriceAndGST(?)",
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			st.setArray(1, conn.createArrayOf("INTEGER", proids.toArray(new Integer[0])));
			ResultSet rst = st.executeQuery();

			while (rst.next()) {
				System.out.println(rst.getInt(1) + rst.getLong(2) + rst.getFloat(3));
				productGST temp = new productGST(rst.getInt(1), rst.getLong(2), rst.getFloat(3));
				pgsts.add(temp);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return pgsts;
	}
}
