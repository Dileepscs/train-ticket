package model_pack;

public class orderProduct extends productGST {
	private int quantity;
	private double totalprice;
	
	public orderProduct(int proid, long unitprice, float gst, int quantity) {
		super(proid, unitprice, gst);
		this.quantity = quantity;
		this.setTotalprice(((this.getGst()/100.0)+this.getUnitprice())*this.getQuantity());
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
}