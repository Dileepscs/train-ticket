package model_pack;

import java.util.Date;

// create table orders25(
// orderid serial primary key,
// order_date date,
// price bigint,
// custid int
// )

public class Order {
	private int orderid;
	private Date order_date;
	private double price;
	private int custid;

	public Order(int orderid, Date order_date, double price, int custid) {
		this.orderid = orderid;
		this.order_date = order_date;
		this.price = price;
		this.custid = custid;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

}
