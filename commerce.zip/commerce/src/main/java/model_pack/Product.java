package model_pack;

// create table products25 (
// proid serial primary key,
// name varchar(100),
// price bigint,
// hsncode varchar(10),
// imgpath varchar(1000),
// catid int
// )

public class Product  {
	private int proid;
	private String name;
	private long price;
	private String hsncode;
	private String imgpath;
	private int catid;

	public Product(int proid, String name, long price, String hsncode, String imgpath, int catid) {
		this.proid = proid;
		this.name = name;
		this.price = price;
		this.hsncode = hsncode;
		this.imgpath = imgpath;
		this.catid = catid;
	}

	public int getProid() {
		return proid;
	}

	public void setProid(int proid) {
		this.proid = proid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public String getHsncode() {
		return hsncode;
	}

	public void setHsncode(String hsncode) {
		this.hsncode = hsncode;
	}

	public String getImgpath() {
		return imgpath;
	}

	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}

	public int getCatid() {
		return catid;
	}

	public void setCatid(int catid) {
		this.catid = catid;
	}

}
