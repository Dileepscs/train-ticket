package model_pack;

// create table categories25(
// catid serial primary key,
// catname varchar(100) unique not null
// )

public class Category {
	private int catid;
	private String catname;

	public Category(int catid, String catname) {
		this.catid = catid;
		this.catname = catname;
	}

	public int getCatid() {
		return catid;
	}

	public void setCatid(int catid) {
		this.catid = catid;
	}

	public String getCatname() {
		return catname;
	}

	public void setCatname(String catname) {
		this.catname = catname;
	}
}
