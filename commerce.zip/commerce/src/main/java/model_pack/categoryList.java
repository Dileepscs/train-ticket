package model_pack;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class categoryList extends ArrayList<Category> {
	ArrayList<Category> cats;

	public categoryList() {
		cats = new ArrayList<>();
	}

	public ArrayList<Category> getCats() {
		return cats;
	}

	public void setCats(ArrayList<Category> cats) {
		this.cats = cats;
	}

}
