package bll_pack;

import java.util.Comparator;

import model_pack.Product;

public class ProductsPriceSorter implements Comparator<Product> {
	// ascending order
	@Override
	public int compare(Product p1, Product p2) {
		return ((int)p1.getPrice()-(int)p2.getPrice());
	}

}
