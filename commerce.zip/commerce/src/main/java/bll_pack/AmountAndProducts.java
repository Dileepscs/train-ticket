package bll_pack;

import java.util.ArrayList;

import model_pack.orderProduct;

public class AmountAndProducts {
	public double caluclateAmount(ArrayList<orderProduct> orderPros) {
		double total = 0;
		for (orderProduct prod : orderPros) {
			System.out.println("unit price is " + prod.getUnitprice());
			System.out.println("gst percent is _> " + prod.getGst() / 100.0);
			System.out.println("Quan tity is " + prod.getQuantity());
			total += (prod.getUnitprice() + (prod.getGst() / 100.0) * prod.getUnitprice()) * prod.getQuantity();
		}
		return total;
	}
}
