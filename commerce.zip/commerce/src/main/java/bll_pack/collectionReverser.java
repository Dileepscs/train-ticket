package bll_pack;

import java.util.ArrayList;
import java.util.Collections;

public class collectionReverser {
	public static ArrayList<?> reverseCollection(ArrayList<?> ls){
		Collections.reverse(ls);
		return ls;
	}
}
