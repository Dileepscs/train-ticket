package control_pack;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import db_pack.categoryDB;
import model_pack.Category;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/categories")
public class categoryServlet extends HttpServlet {
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		rs.setContentType("application/json");
		JSONObject outerjsobj = new JSONObject();
		categoryDB cdb = new categoryDB();

		ArrayList<Category> cats = cdb.getAllCategories();
		ArrayList<JSONObject> jsobjs = new ArrayList<>();

		// private int catid;
		// private String catname;

		for (Category cat : cats) {
			JSONObject innerjsobj = new JSONObject();
			innerjsobj.put("catid", cat.getCatid());
			innerjsobj.put("catname", cat.getCatname());
			jsobjs.add(innerjsobj);
		}
		outerjsobj.put("categories", jsobjs);

		PrintWriter pw = rs.getWriter();
		pw.write(outerjsobj.toString());
	}
}
