package control_pack;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.json.JSONObject;

import bll_pack.ProductsNameSorter;
import bll_pack.ProductsPriceSorter;
import bll_pack.collectionReverser;
import db_pack.productDb;
import model_pack.Product;

@SuppressWarnings("serial")
@WebServlet(urlPatterns="/productSorter")
public class productSortServlet extends HttpServlet {
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException{
		rs.setContentType("application/json");
		JSONObject outerjsobj = new JSONObject();
		productDb pdb = new productDb();

		ArrayList<Product> pls = pdb.getAllCategoryProducts(Integer.parseInt(rq.getParameter("category_id")));
		
		if(Math.abs(Integer.parseInt(rq.getParameter("sort_val")))==1) {
			Collections.sort(pls,new ProductsPriceSorter());
		}else if(Math.abs(Integer.parseInt(rq.getParameter("sort_val")))==2) {
			Collections.sort(pls,new ProductsNameSorter());
		}
		
		if(Integer.parseInt(rq.getParameter("sort_val"))<0) {
			Collections.reverse(pls);
		}
		
		ArrayList<JSONObject> jsobjs = new ArrayList<>();

		for (Product prod : pls) {
			JSONObject innerjsobj = new JSONObject();
			innerjsobj.put("proid", prod.getProid());
			innerjsobj.put("name", prod.getName());
			innerjsobj.put("price", prod.getPrice());
			innerjsobj.put("hsncode", prod.getHsncode());
			innerjsobj.put("imgpath", prod.getImgpath());
			innerjsobj.put("catid", prod.getCatid());
			jsobjs.add(innerjsobj);
		}
		outerjsobj.put("products", jsobjs);
		PrintWriter pw = rs.getWriter();
		pw.write(outerjsobj.toString());
	}
}
