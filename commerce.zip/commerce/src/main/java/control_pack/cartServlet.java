package control_pack;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import db_pack.productDb;
import model_pack.Product;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/cart")
public class cartServlet extends HttpServlet {
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		Cookie[] cks = rq.getCookies();
		String decodedCookie = "";

		for (Cookie ck : cks) {
			if (ck.getName().equals("cart_objs")) {
				decodedCookie = URLDecoder.decode(ck.getValue(), "UTF-8");
			}
		}

		JSONObject x = new JSONObject(decodedCookie);
		ArrayList<Integer> reqProIds = new ArrayList<>();
		HashMap<Integer, Integer> proQuantity = new HashMap<>();

		for (String key : x.keySet()) {
			reqProIds.add(Integer.parseInt(key));
			proQuantity.put(Integer.parseInt(key), x.getInt(key));
		}

		productDb pdb = new productDb();
		HashMap<Product, Integer> reqProducts = pdb.getReqProducts(reqProIds, proQuantity);

		JSONObject outerjsobj = new JSONObject();
		ArrayList<JSONObject> jsobjs = new ArrayList<>();

		for (Product prod : reqProducts.keySet()) {
			JSONObject innerjsobj = new JSONObject();
			innerjsobj.put("proid", prod.getProid());
			innerjsobj.put("name", prod.getName());
			innerjsobj.put("price", prod.getPrice());
			innerjsobj.put("hsncode", prod.getHsncode());
			innerjsobj.put("imgpath", prod.getImgpath());
			innerjsobj.put("catid", prod.getCatid());
			innerjsobj.put("quantity", reqProducts.get(prod));
			jsobjs.add(innerjsobj);
		}
		outerjsobj.put("userProducts", jsobjs);

		@SuppressWarnings("deprecation")
		Cookie procookie = new Cookie("userProducts", URLEncoder.encode(outerjsobj.toString(), "UTF-8"));
		System.out.println(procookie.getValue());
		rs.addCookie(procookie);

		RequestDispatcher rd = rq.getRequestDispatcher("static_content/assets/HTMLFiles/cart.html");
		rd.forward(rq, rs);
	}
}
