package control_pack;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import bll_pack.AmountAndProducts;
import db_pack.orderDB;
import db_pack.productDb;
import model_pack.Order;
import model_pack.Product;
import model_pack.orderProduct;
import model_pack.productGST;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/checkOut")
public class checkOutServlet extends HttpServlet {
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		RequestDispatcher rd = rq.getRequestDispatcher("static_content/assets/HTMLFiles/checkout.html");
		
		Cookie[] cks = rq.getCookies();
		String decodedCookie = "";

		for (Cookie ck : cks) {
			if (ck.getName().equals("cart_objs")) {
				System.out.println(ck.getValue());
				decodedCookie = URLDecoder.decode(ck.getValue(), "UTF-8");
				System.out.println(decodedCookie);
			}
		}

		JSONObject userprods = new JSONObject(decodedCookie);
		HashMap<Integer, Integer> userProdsQuan = new HashMap<>();
		productDb pdb = new productDb();
		ArrayList<Integer> prodIds = new ArrayList<>();

		for (String proid : userprods.keySet()) {
			int curr_proId = Integer.parseInt(proid);
			prodIds.add(curr_proId);
			userProdsQuan.put(curr_proId, userprods.getInt(proid));
		}
		System.out.println(userProdsQuan);

		ArrayList<productGST> cartProds = pdb.getProductsPriceAndGST(prodIds);
		ArrayList<orderProduct> orderProds = new ArrayList<>();

		for (productGST ele : cartProds) {
			orderProduct curr = new orderProduct(ele.getProid(), ele.getUnitprice(), ele.getGst(),
					userProdsQuan.get(ele.getProid()));
			orderProds.add(curr);
		}

		AmountAndProducts aapObj = new AmountAndProducts();
		double totalPrice = aapObj.caluclateAmount(orderProds);

		orderDB odb = new orderDB();
		Order ord=odb.createOrder(totalPrice);

		// create orderProducts for all the Products
		odb.createOrderProducts(orderProds, ord);
		
		HashMap<Product, Integer> reqProducts = pdb.getReqProducts(prodIds, userProdsQuan);

		// products:  user product name | unit price | gst | quantity | total price 
		// total_order_price : double
		
		JSONObject outerjsobj= new JSONObject();
		ArrayList<JSONObject> jsobjsCart = new ArrayList<>();
		for(orderProduct ele : orderProds) {
			JSONObject innerjsobj = new JSONObject();
			innerjsobj.put("product_id", ele.getProid());
			innerjsobj.put("unit_price", ele.getUnitprice());
			innerjsobj.put("gst", ele.getGst());
			innerjsobj.put("quantity", ele.getQuantity());
			innerjsobj.put("total_price", ele.getTotalprice());
			jsobjsCart.add(innerjsobj);
		}
		outerjsobj.put("UserCheckoutProducts", jsobjsCart);
		outerjsobj.put("TotalOrderPrice", totalPrice);
		System.out.println(outerjsobj.toString());
		rs.getWriter().write(outerjsobj.toString());
		
		@SuppressWarnings("deprecation")
		Cookie ck = new Cookie("checkOutProducts", URLEncoder.encode(outerjsobj.toString()));
		rs.addCookie(ck);
		
		rd.forward(rq, rs);
	}
}
