$(document).ready(function(){
    if (!sessionStorage.getItem('reloaded')) {
        sessionStorage.setItem('reloaded', 'true');
        location.reload();
    }

    function getCookie(name) {
        const cookieValue = document.cookie
        .split('; ')
        .find(row => row.startsWith(name + '='));
    const value = cookieValue ? cookieValue.split('=')[1] : null;
    return value ? decodeURIComponent(value) : null;
    }

	let jsObj = JSON.parse(getCookie("checkOutProducts"));

    let userBilledProducts = jsObj["UserCheckoutProducts"];
    let total_price = jsObj["TotalOrderPrice"];

    let billspace=$("#billSpace");
    let tab = $("<table></table>");
    tab.attr("border","1");
    
    let tabhead = $("<tr></tr>");
    
    tabhead.append($("<th></th>").text("Product Name"));
    tabhead.append($("<th></th>").text("Unit Price"));
    tabhead.append($("<th></th>").text("GST"));
    tabhead.append($("<th></th>").text("Quantity"));
    tabhead.append($("<th></th>").text("Total Price"));
    
    tab.append(tabhead);
    for(let i=0;i<userBilledProducts.length;i++){
        let obj = userBilledProducts[i];

        let tabrow = $("<tr></tr>");
        tabrow.append($("<td></td>").text(obj["product_id"]));
        tabrow.append($("<td></td>").text(obj["unit_price"]));
        tabrow.append($("<td></td>").text(obj["gst"]));
        tabrow.append($("<td></td>").text(obj["quantity"]));
        tabrow.append($("<td></td>").text(obj["total_price"]));
        tab.append(tabrow);
    }

    billspace.append(tab);

    billspace.append(total_price);
});
