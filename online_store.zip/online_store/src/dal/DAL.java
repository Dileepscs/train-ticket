package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAL {
	public static final String URL = "jdbc:postgresql://192.168.110.48:5432/plf_training";
	public static final String UNAME = "plf_training_admin";
	public static final String PWD = "pff123";
	public static Connection con;

	public PreparedStatement st;
	public ResultSet rs;
	public String query;

	public DAL() {
		con = null;
		try {

			con = DriverManager.getConnection(URL, UNAME, PWD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
